import os
import time
from datetime import datetime
from itertools import islice
import csv
import json
import pandas as pd
import twd97
from geojson import Feature, Point, FeatureCollection

import influxdb_client
# 導入客戶端
from influxdb_client import InfluxDBClient, Point, WriteOptions
# 指定寫入選項
from influxdb_client.client.write_api import SYNCHRONOUS

file = 'GW_202210.csv'

def insertdatabase(json_body):
    # 這邊的資訊請填入自己的 不改的話一定連不上平台
    org="ait"
    bucket = "all"
    token = "_hHSpwvaoU4ydLOZ8tEYud83aE1aldZ5jafbiFUNB7vN4vcgVZH3-pVBB_rde3AAOPdOEocQmyIKvOUO31-duw=="
    url = "http://127.0.0.1:8086" # 使用 CT 執行程式用 localhost
    # url = "http://192.168.0.137:8086" 如果從windows寫入就用 CT IP 連線
    
    # 建立連結
    client = InfluxDBClient(
        url=url,
        token=token,
        org=org
    )
    # 使用寫入 API
    write_api = client.write_api(write_options=SYNCHRONOUS)
    write_api.write(bucket, org, json_body)

def main():
    print("data name:", file)
    with open('/root/{}'.format(file), 'r',encoding="Big5") as in_file:
        rows = csv.reader(in_file)
        json_body = []
        header = next(rows)
        
        start=time.time()
        i = 0
        for row in islice(rows, 1, None):
            rowdata = {}
            rowdata["measurement"]=str(row[2]).replace(' ','')
            temptime=datetime.strptime(str(row[5]), "%Y-%m-%d %H:%M").isoformat()
            rowdata["time"]=temptime
            rowdata["tags"]={}
            rowdata["fields"]={}
            rowdata["tags"]["ST_NO"]=str(row[2]).replace(' ','')
            rowdata["tags"]["NAME_C"]=str(row[3]).replace(' ','')
            rowdata["fields"]["Water_Level"]=float(row[6])
            json_body.append(rowdata)

            i+=1
            if i==100:
                insertdatabase(json_body)
                json_body = []
                i-=100
            
        end = time.time()
        end = end-start
        end = round(end,4)
        print("Upload to Influxdb time: ",end)

if __name__ == '__main__':
    main()