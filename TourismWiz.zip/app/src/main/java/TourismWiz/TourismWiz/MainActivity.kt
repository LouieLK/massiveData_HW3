package TourismWiz.TourismWiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.ui.tooling.preview.Preview
import TourismWiz.TourismWiz.ui.theme.TourismWizTheme
import android.util.Log
import androidx.compose.material.Button
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContent {
            TourismWizTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                ) {
                    DefaultPreview()
                }
            }
        }

    }
}

@Composable
fun Hotel(hotelName:String,descreption:String){
    Row{
        val painter: Painter = painterResource(id = R.drawable.test)
        Image(
            painter = painter,
            contentDescription = "My image" ,
            modifier = Modifier
                    .size(width = LocalConfiguration.current.screenWidthDp.dp/2, height = LocalConfiguration.current.screenWidthDp.dp/2)
        )
        Column {
            Text(text = hotelName,
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            Text(text = descreption,
                fontStyle = FontStyle.Normal,
                fontSize = 12.sp
            )
        }
    }

}

var a:Int=0
@Composable
fun SimpleButton(mes:String) {
    val buttonText = remember { mutableStateOf("$mes⬇") }
    var listResult: List<MarsPhoto>?
    Button(
        modifier = Modifier.size(height=40.dp, width = LocalConfiguration.current.screenWidthDp.dp/3),
        onClick = {
            if(a%2==0)
                buttonText.value="$mes⬇"
            else
                buttonText.value="$mes⬆"
            a++
//        try {
//            runBlocking {
//                listResult = MarsApi.retrofitService.getPhotos()
//                Log.d("LouieK", listResult?.get(0)?.img_src.toString())
//            }
//        }catch (e:java.lang.Exception){
//
//        }
    }) {
        Text(text = buttonText.value)
    }
}
@Composable
fun TextInputField() {
    val textState = remember { mutableStateOf(TextFieldValue()) }
    TextField(
        value = textState.value,
        onValueChange = { textState.value = it },
        modifier = Modifier.fillMaxWidth(),
        label = { Text("搜尋") }
    )
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    TourismWizTheme {
        Column {
            TextInputField()
            Row {
                SimpleButton("價格")
                SimpleButton("距離")
                SimpleButton("??")
            }
            LazyColumn() {
                item {
                    for (i in 0..10) {
                        Hotel(
                            hotelName = "台北晶華酒店",
                            descreption = "台北晶華酒店座落在富有活力與文化、娛樂與購物的中心區域，是國內外商務及休閒旅客的住宿上選。從寬敞奢華的住宿享受、先進高端的會議場地，到精緻非凡的用餐體驗及客製化的娛樂設施，我們獨幟一格的軟硬體設備將能滿足並超越顧客們的期待。"
                        )
                    }
                }
            }
        }
    }
}