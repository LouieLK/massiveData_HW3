package TourismWiz.TourismWiz

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.POST

private val ClientId:String="00957050-3b2adeb1-206e-45bc"
private val ClientSecret:String ="0d104935-2980-4680-9758-4f05bd908928"
//private const val BASE_URL =
//    "https://tdx.transportdata.tw/api/basic/v2/Tourism/Hotel?%24top=30&%24format=JSON"
private const val BASE_URL =
    "https://android-kotlin-fun-mars-server.appspot.com"

private val retrofit = Retrofit.Builder()
    .addConverterFactory(Json.asConverterFactory(MediaType.get("application/json")))
    .baseUrl(BASE_URL)
    .build()


object MarsApi {
    val retrofitService : MarsApiService by lazy {
        retrofit.create(MarsApiService::class.java)
    }
}


interface MarsApiService {
    @GET("id")
    suspend fun getId():Int

    @GET("photos")
    suspend fun getPhotos():List<MarsPhoto>
}
